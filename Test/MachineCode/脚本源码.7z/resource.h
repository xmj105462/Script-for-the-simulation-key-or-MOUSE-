﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 MachineCode.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MACHINECODE_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDR_BMP1                        132
#define IDB_BITMAP1                     133
#define IDB_BITMAP2                     134
#define IDD_DIALOG_FUNC                 135
#define IDC_EDIT_MACHINE_CODE           1005
#define IDC_EDIT_PASSWORD               1006
#define IDC_BUTTON_LOGIN                1007
#define IDC_CHECK_QZ                    1008
#define IDC_CHECK_ZD                    1009
#define IDC_CHECK_SC                    1010
#define IDC_CHECK_JBZS                  1012
#define IDC_TIP                         1012
#define IDC_CHECK_DD                    1013
#define IDC_CHECK_XJ                    1014
#define IDC_CHECK_FY                    1015
#define IDC_CHECK_PR                    1016
#define IDC_CHECK_JB                    1017
#define IDC_CHECK_YJ                    1018
#define IDC_CHECK1                      1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
